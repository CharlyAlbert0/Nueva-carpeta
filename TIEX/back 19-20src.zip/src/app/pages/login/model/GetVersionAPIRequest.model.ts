export class GetVersionAPIRequest {
    IP?: string;
    DeviceInfo?: string;
}