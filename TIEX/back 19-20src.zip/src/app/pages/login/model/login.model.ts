export class LoginModel {
    user: string;
    password: string;
    wasPasswordValidate: string;
}
