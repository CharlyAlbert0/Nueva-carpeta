export class GetVersionAPIResponse {
    Version?: string;
    WelcomeMessageSystem?: string;
    ReturnCode?:string;
    Message?:string;
    Description?:string;
} 