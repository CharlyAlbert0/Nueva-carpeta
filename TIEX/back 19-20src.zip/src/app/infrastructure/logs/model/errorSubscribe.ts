import {errorSubscribeBodyModel} from './errorSubscribeBody';

export class errorSubscribeModel{
  headers:string;
  ok:string;
  status:string;
  statusText:string;
  type:string;
  url:string;
  _body:string;
  Body:errorSubscribeBodyModel;
}
