import { Component, OnInit } from '@angular/core';

declare var $:any;

@Component({
    moduleId: module.id,
    selector: 'regularforms-cmp',
    templateUrl: 'regularforms.component.html'
})

export class RegularFormsComponent implements OnInit{

    ngOnInit(){
    }
}
