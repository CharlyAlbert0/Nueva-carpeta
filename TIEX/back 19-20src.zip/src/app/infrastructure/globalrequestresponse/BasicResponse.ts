export class BasicResponse {
    ReturnCode?:string;
    Message?:string;
    Description?:string;
}