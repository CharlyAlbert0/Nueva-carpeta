export enum EnumLogType {
    Error =1 ,
    Warning = 2,
    Info = 3
}

export enum EnumLogPriority {
    Hight =1 ,
    Medium = 2,
    Low = 3
}
